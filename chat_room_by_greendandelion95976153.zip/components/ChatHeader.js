function ChatHeader() {
  const [showAccount, setShowAccount] = React.useState(false);
  const [password, setPassword] = React.useState('');
  const [isEditing, setIsEditing] = React.useState(false);
  const [editedUsername, setEditedUsername] = React.useState('');
  const [editedPassword, setEditedPassword] = React.useState('');
  const { client } = room.party;

  const generatePassword = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let pass = '';
    for (let i = 0; i < 12; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setPassword(pass);
    setEditedPassword(pass);
  };

  React.useEffect(() => {
    if (showAccount && !password) {
      generatePassword();
    }
    setEditedUsername(client.username);
  }, [showAccount]);

  const handleSave = () => {
    // In a real app, you would update these values in your backend
    // For now we'll just show them in the UI
    setIsEditing(false);
  };

  return (
    <div className="chat-header">
      <button 
        className="account-button" 
        onClick={() => setShowAccount(!showAccount)}
      >
        <i className="ri-user-line"></i> MON COMPTE
      </button>
      <div className="title">
        <i className="ri-terminal-box-line"></i> HACK CHAT
      </div>

      {showAccount && (
        <div className="account-modal">
          <div className="account-modal-content">
            <div className="modal-header">
              <h3>INFORMATIONS COMPTE</h3>
              <button 
                className="close-button"
                onClick={() => setShowAccount(false)}
              >
                <i className="ri-close-line"></i>
              </button>
            </div>
            <div className="account-info">
              <div className="info-row">
                <span className="label">PSEUDO:</span>
                {isEditing ? (
                  <input
                    type="text"
                    className="edit-input"
                    value={editedUsername}
                    onChange={(e) => setEditedUsername(e.target.value)}
                  />
                ) : (
                  <span className="value">{editedUsername}</span>
                )}
              </div>
              <div className="info-row">
                <span className="label">MOT DE PASSE:</span>
                <div className="password-container">
                  {isEditing ? (
                    <input
                      type="text"
                      className="edit-input"
                      value={editedPassword}
                      onChange={(e) => setEditedPassword(e.target.value)}
                    />
                  ) : (
                    <span className="value">{editedPassword || password}</span>
                  )}
                  <button 
                    className="regenerate-button"
                    onClick={generatePassword}
                    title="Générer nouveau mot de passe"
                  >
                    <i className="ri-refresh-line"></i>
                  </button>
                </div>
              </div>
              <div className="button-row">
                {isEditing ? (
                  <button className="cyber-button" onClick={handleSave}>
                    <i className="ri-save-line"></i> SAUVEGARDER
                  </button>
                ) : (
                  <button className="cyber-button" onClick={() => setIsEditing(true)}>
                    <i className="ri-edit-line"></i> MODIFIER
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}